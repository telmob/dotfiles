#!/usr/bin/env bash

icon=""
echo " $icon "

rofi -location 3 -yoffset 805 -xoffset -10 -width 37 -font "Ubuntu 11" -padding 20 -line-padding 4 -hide-scrollbar -password
